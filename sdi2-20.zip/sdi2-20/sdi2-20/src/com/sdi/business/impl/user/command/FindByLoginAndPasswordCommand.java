package com.sdi.business.impl.user.command;

import com.sdi.business.exception.BusinessException;
import com.sdi.business.impl.command.Command;
import com.sdi.dto.User;

public class FindByLoginAndPasswordCommand implements Command<User> {

	@Override
	public User execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}
