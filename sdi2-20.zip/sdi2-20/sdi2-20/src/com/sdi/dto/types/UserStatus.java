package com.sdi.dto.types;

public enum UserStatus {

	ENABLED, DISABLED

}
